function servercmdvceget(%client, %a, %b, %c, %d, %e, %f, %g, %h, %i, %j) //Just a command which lets the client see vars
{
	%var = trim(%a SPC %b SPC %c SPC %d SPC %e SPC %f SPC %g SPC %h SPC %i SPC %j);
	if(!strlen(%var)) return;
	%player = %client.player;
	if(!isObject(%player) || %player.getState $= "Dead")
		%player = 0;
	else {
		%start = getWords(%player.getEyeTransform(),0,2);
		%end = vectorAdd(%start, vectorScale(%player.getEyeVector(),10));
		%ray = ContainerRayCast(%start, %end, $TypeMasks::FxBrickObjectType);
		%brick = getWord(%ray,0);
		if(!isObject(%brick))
			%brick = 0;
	}
	%done = filterVariableString(%var,%brick,%client,%player);
	messageClient(%client,'',"<color:ffff00>" @ %var @ "<color:ffffff> reads as <color:ffff00>" @ (strLen(trim(%done)) > 0 ? trim(%done) : "<color:ffffff>blank") @ "<color:ffffff>.");
}


function getYawB(%this)
{
	%fv = %this.getForwardVector();
	%pi = 3.1415926535897932384626433;
	%x = mASin(getWord(%fv,0)) * 180 / %pi;
	return 180 - mFloatLength(%x / mAbs(%x),0) * (180 - (mACos(getWord(%fv,1)) * 180 / %pi));
}

function getPitchB(%this)
{
	%fv = %this.getEyeVector();
	%pi = 3.1415926535897932384626433;
	return mASin(getWord(%fv,2)) * 180 / %pi;
}

function VCE_Player_setYaw(%player,%yaw)
{
	%pos = %player.getPosition();
	%rot = mDegToRad(%yaw+0);
	%player.setTransform(%pos SPC "0 0 1" SPC %rot);
}

function VCE_Vehicle_setYaw(%vehicle,%yaw)
{
	VCE_Player_setYaw(%vehicle,%yaw); //Lazy way :P
}

function VCE_Vehicle_setPosition(%vehicle,%position)
{
	%vehicle.setTransform(vectorAdd(%position, "0 0 0") SPC getWords(%vehicle.getTransform(),3,7));
}

//Sadly, theres no easy way that i know of to set a players pitch server-sided :C

function VCE_Player_setHealth2(%player,%amount) //Fixes for setting health < 0 deleting player
{
	if(%amount <= 0)
	{
		%player.kill();
		return;
	}
	if(%amount > %player.getDatablock().maxDamage)
		%amount = %player.getDatablock().maxDamage;
	%player.setDamageLevel(%player.getDatablock().maxDamage - %amount);
}

function VCE_Player_setDamage2(%player,%amount)
{
	if(%amount < 0)
		%amount = 0;
	if(%amount >= %player.getDatablock().maxDamage)
	{
		%player.kill();
		return;
	}
	%player.setDamageLevel(%amount);
}

function VCE_Player_setScale(%player, %scale)
{
	%player.setScale(vectorAdd(%scale, "0 0 0")); //Adding "0 0 0" forces it to be a 3d vector
}
function VCE_Vehicle_setScale(%vehicle, %scale)
{
	%vehicle.setScale(vectorAdd(%scale, "0 0 0")); //Adding "0 0 0" forces it to be a 3d vector
}

package advVCEVarReplacers
{
	function VCE_initServer()
	{
		Parent::VCE_initServer();
		registerSpecialVar(Player,"rhealth","mCeil(%this.getDatablock().maxDamage - %this.getDamageLevel())","setDamage2");
		registerSpecialVar(Player,"renergy","mCeil(%this.getEnergyLevel())","setEnergy");
		registerSpecialVar(Player,"rdamage","mFloor(%this.getDamageLevel())","setDamage2");
		registerSpecialVar(Player,"pos","getWords(%this.getTransform(),0,2)","setPosition");
		registerSpecialVar(Player,"state","%this.getstate()");
		registerSpecialVar(Player,"isPassenger","(%this.getObjectMount().dataBlock.rideable)");
		registerSpecialVar(Player,"isDriver","(%this.getObjectMount().dataBlock.rideable && %this.getObjectMount().getControllingObject() == %this)");
		registerSpecialVar(Player,"altFire","%this.slot1");
		registerSpecialVar(Player,"veDamage","%this.getObjectMount() ? %this.getObjectMount().getDamageLevel() : 0");
		registerSpecialVar(Player,"veHealth","%this.getObjectMount() ? %this.getObjectMount().getDatablock().maxDamage - %this.getObjectMount().getDamageLevel() : 0");
		registerSpecialVar(Player,"veMaxHealth","%this.getObjectMount() ? %this.getObjectMount().getDatablock().maxDamage : 0");
		registerSpecialVar(Player,"veDatablock","%this.getObjectMount() ? %this.getObjectMount().getDatablock().uiName : 0");
		registerSpecialVar(Player,"weDamage","%this.tool[%this.currTool].image.projectile.directDamage + 0");
		registerSpecialVar(Player,"weRadiusDamage","%this.tool[%this.currTool].image.projectile.explosion.radiusDamage + 0");
		registerSpecialVar(Player,"weDamageRadius","%this.tool[%this.currTool].image.projectile.explosion.damageRadius + 0");
		registerSpecialVar(Player,"weSpeed","%this.tool[%this.currTool].image.projectile.muzzleVelocity + 0");
		registerSpecialVar(Player,"weArc","%this.tool[%this.currTool].image.projectile.isBallistic*%this.tool[%this.currTool].image.projectile.gravityMod + 0");
		registerSpecialVar(Player,"item6","%this.tool[5].uiName","setItem",5);
		registerSpecialVar(Player,"item7","%this.tool[6].uiName","setItem",6);
		registerSpecialVar(Player,"item8","%this.tool[7].uiName","setItem",7);
		registerSpecialVar(Player,"item9","%this.tool[8].uiName","setItem",8);
		registerSpecialVar(Player,"item10","%this.tool[9].uiName","setItem",9);
		registerSpecialVar(Player,"yaw","getYawB(%this)","setYaw");
		registerSpecialVar(Player,"pitch","getPitchB(%this)");
		registerSpecialVar(Player,"eyevec","%this.getEyeVector()");
		registerSpecialVar(Player,"eyevecx","getWord(%this.getEyeVector(),0)");
		registerSpecialVar(Player,"eyevecy","getWord(%this.getEyeVector(),1)");
		registerSpecialVar(Player,"eyevecz","getWord(%this.getEyeVector(),2)");
		registerSpecialVar(Player,"eyepos","getWords(%this.getEyeTransform(),0,2)");
		registerSpecialVar(Player,"eyeposx","getWord(%this.getEyeTransform(),0)");
		registerSpecialVar(Player,"eyeposy","getWord(%this.getEyeTransform(),1)");
		registerSpecialVar(Player,"eyeposz","getWord(%this.getEyeTransform(),2)");
		registerSpecialVar(Player,"scale","%this.getScale()","setScale");
		registerSpecialVar(Player,"scalex","getWord(%this.getScale(),0)");
		registerSpecialVar(Player,"scaley","getWord(%this.getScale(),1)");
		registerSpecialVar(Player,"scalez","getWord(%this.getScale(),2)");

		registerSpecialVar(GameConnection,"paintcolorid","%this.currentColor");
		registerSpecialVar(GameConnection,"paintcolor","getColorIDTable(%this.currentColor)");
		registerSpecialVar(GameConnection,"paintcolorr","getWord(getColorIDTable(%this.currentColor),0)");
		registerSpecialVar(GameConnection,"paintcolorg","getWord(getColorIDTable(%this.currentColor),1)");
		registerSpecialVar(GameConnection,"paintcolorb","getWord(getColorIDTable(%this.currentColor),2)");
		registerSpecialVar(GameConnection,"paintcolora","getWord(getColorIDTable(%this.currentColor),3)");

		//Fixes for setting health to less than 0 deleting player
		unregisterSpecialVar(Player,"health");
		unregisterSpecialVar(Player,"damage");
		registerSpecialVar(Player,"damage","%this.getDamageLevel()","setDamage2");
		registerSpecialVar(Player,"health","%this.getDatablock().maxDamage - %this.getDamageLevel()","setHealth2");

		registerSpecialVar(fxDTSbrick,"pos","%this.getPosition()");
		registerSpecialVar(fxDTSbrick,"type","%this.getDataBlock().getID().category");
		registerSpecialVar(fxDTSbrick,"color","getColorIDTable(%this.getColorId())");
		registerSpecialVar(fxDTSbrick,"colorr","getWord(getColorIDTable(%this.getColorId()),0)");
		registerSpecialVar(fxDTSbrick,"colorg","getWord(getColorIDTable(%this.getColorId()),1)");
		registerSpecialVar(fxDTSbrick,"colorb","getWord(getColorIDTable(%this.getColorId()),2)");
		registerSpecialVar(fxDTSbrick,"colora","getWord(getColorIDTable(%this.getColorId()),3)");

		registerSpecialVar(Vehicle,"pos","getWords(%this.getTransform(),0,2)","setPosition");
		registerSpecialVar(Vehicle,"yaw","getWord(axisToEuler(getWords(%this.getTransform(),3,6)),2)","setYaw");
		registerSpecialVar(Vehicle,"pitch","getWord(axisToEuler(getWords(%this.getTransform(),3,6)),0)");
		registerSpecialVar(Vehicle,"roll","getWord(axisToEuler(getWords(%this.getTransform(),3,6)),1)");
		registerSpecialVar(Vehicle,"scale","%this.getScale()","setScale");
		registerSpecialVar(Vehicle,"scalex","getWord(%this.getScale(),0)");
		registerSpecialVar(Vehicle,"scaley","getWord(%this.getScale(),1)");
		registerSpecialVar(Vehicle,"scalez","getWord(%this.getScale(),2)");


		registerSpecialVar("GLOBAL","simSecond","mFloor(getSimTime()/1000)");
		registerSpecialVar("GLOBAL","simMinute","mFloor(getSimTime()/60000)");
		registerSpecialVar("GLOBAL","simHour","mFloor(getSimTime()/3600000)");
	}

	function Armor::onTrigger(%data,%player,%slot,%io)
	{
		Parent::onTrigger(%data,%player,%slot,%io);

		if(%slot == 1)
			%player.slot1 = %io;
	}

	function WheeledVehicleData::onTrigger(%this, %obj, %client)
	{
		if(!%this.triggerOn)
			%this.triggerOn = 1;
		else
			%this.triggerOn = 0;
	}

	function FlyingVehicleData::onTrigger(%this, %obj, %client)
	{
		if(!%this.triggerOn)
			%this.triggerOn = 1;
		else
			%this.triggerOn = 0;
	}
};
activatePackage(advVCEVarReplacers);