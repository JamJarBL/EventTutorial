function CT_O_Add(%a, %b) {
	%aType = CodeTags_getValueType(%a);
	%bType = CodeTags_getValueType(%b);

	switch$(%aType) {
		case "Number":
			switch$(%bType) {
				case "Number": //Num + Num
					return %a + %b;
				case "Vector": //No idea

				case "String": //Add %a to beginning of %b
					return %a @ %b;
				case "Array": //If type is the same, add to end of array

			}
		case "Vector":
			switch$(%bType) {
				case "Number": //No idea
					
				case "Vector": //VectorAdd
					//Do vector add stuff
				case "String":
					return CT_Vector_getComponents(%a) @ %b;
				case "Array": //If type is the same, add to end of array

			}
		case "String":
			switch$(%bType) {
				case "Number": //Put %b on the end of %a
					return %a @ %b;
				case "Vector": //No idea

				case "String": //Add %a to beginning of %b
					return %a @ %b;
				case "Array": //If type is the same, add to end of array

			}
		case "Array":
			switch$(%bType) {
				case "Number": //If type is the same, add to end of array
					
				case "Vector": //If type is the same, add to end of array

				case "String": //If type is the same, add to end of array
					
				case "Array": //Add arrays together

			}
	}
} //Oh god, do i have to do this for every single operator? D:

function CT_O_Subtract(%a, %b) {
	%aType = CodeTags_getValueType(%a);
	%bType = CodeTags_getValueType(%b);

	switch$(%aType) {
		case "Number":
			switch$(%bType) {
				case "Number": //Num - Num
					return %a - %b;
				case "Vector": //No idea

				case "String": //No idea

				case "Array": //No idea

			}
		case "Vector":
			switch$(%bType) {
				case "Number": //No idea
					
				case "Vector": //VectorSub
					//Do vector sub stuff
					return;
				case "String": //No idea

				case "Array": //No idea

			}
		case "String":
			switch$(%bType) {
				case "Number": //No idea

				case "Vector": //No idea

				case "String": //Remove first case of %b in %a
					
				case "Array": //No idea

			}
		case "Array":
			switch$(%bType) {
				case "Number": //No idea
					
				case "Vector": //If type is the same, add to end of array

				case "String": //If type is the same, add to end of array
					return %a @ %b;
				case "Array": //Add arrays together

			}
	}
} //Oh god, do i have to do this for every single operator? D: