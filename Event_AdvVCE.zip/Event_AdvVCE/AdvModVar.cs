//////////////////////////////////
//Code obviously copied from VCE//
//////////////////////////////////

registerOutputEvent(fxDtsBrick,"VCE_advModVariable","list Brick 0 Player 1 Client 2 Minigame 3 Vehicle 4\tstring 128 100\tlist Sin 0 Cos 1 Tan 2 DegToRad 3 RadToDeg 4 FloatLength 5 VectorAdd 6 VectorSub 7 VectorScale 8 VectorDist 9 VectorLen 10 VectorNormalize 11 GetSubStr 12 StrPos 13\tstring 128 255",1);
registerOutputEvent(fxDtsBrick,"VCE_advModVar",    "list Brick 0 Player 1 Client 2 Minigame 3 Vehicle 4\tstring 128 100\tlist Sin* 0 InvSin* 1 Cos* 2 InvCos* 3 Tan* 4 InvTan 5 DegToRad* 6 RadToDeg* 7 FloatLength 8 FloorTo 9 RoundTo 10 CeilTo 11 RandomInt 12 RandomFloat 13 Interpolate 14\tstring 128 255",1);
registerOutputEvent(fxDtsBrick,"VCE_modVectorVar", "list Brick 0 Player 1 Client 2 Minigame 3 Vehicle 4\tstring 128 100\tlist Add 0 Subtract 1 Scale 2 Multiply 3 Divide 4 Length* 5 Normalize* 6 Distance 7 Lerp 8 Slerp 9 AngleBetween 10 convertToAngle* 11 createFromAngle* 12 RotateByAngle 13\tstring 128 255",1);
registerOutputEvent(fxDtsBrick,"VCE_modStringVar", "list Brick 0 Player 1 Client 2 Minigame 3 Vehicle 4\tstring 128 100\tlist WordCount* 0 GetWords 1 SetWord 2 WordIndex 3 CharLength* 4 PosOfChar 5 GetSubStr 6 GetSubStr2 7 Replace** 8\tstring 128 255",1);

function fxDtsBrick::VCE_advModVar(%brick, %type, %name, %logic, %value, %client)
{
	%player = %client.player;
	if(%client.blockVCE[getBrickGroupFromObject(%brick).bl_id])
		return;

	if(isObject(%player) && getSimTime() - %player.spawnTime < $VCE::Server::ImmuneTime)
		return;

	if(isObject(%brick.getGroup().vargroup))
	{
		switch(%type)
		{
			case 0:
				%category = "Brick";
				%target = %brick;
				%class = "fxDtsBrick";
			case 1:
				%category = "Player";
				%target = %player;
				%class = "Player";
			case 2:
				%category = "Client";
				%target = %client;
				%class = "GameConnection";
			case 3:
				%category = "Minigame";
				%target = getMinigameFromObject(%brick);
				%class = "MinigameSO";
			case 4:
				%category = "Vehicle";
				%target = %brick.vehicle;
				%class = "Vehicle";
		}
		if(!isObject(%target))
			return;
		%name = filterVariableString(%name, %brick, %client, (isObject(%player) ? %player : 0));
		%oldvalue = %brick.getGroup().vargroup.getVariable(%category, %name, %target);
		%newvalue = filterVariableString(%value, %brick, %client, (isObject(%player) ? %player : 0));

		switch(%logic)
		{
			case 0: //Sin
				%value = mSin(mDegToRad(getWord(%oldvalue, 0)+0));
			case 1: //InvSin
				%value = mRadToDeg(mASin(getWord(%oldvalue, 0)+0));
			case 2: //Cos
				%value = mCos(mDegToRad(getWord(%oldvalue, 0)+0));
			case 3: //InvCos
				%value = mRadToDeg(mACos(getWord(%oldvalue, 0)+0));
			case 4: //Tan
				%value = mTan(mDegToRad(getWord(%oldvalue, 0)+0));
			case 5: //InvTan
				%value = mRadToDeg(mATan(getWord(%newvalue, 0)+0, getWord(%newvalue, 1)+0));
			case 6: //DegToRad
				%value = mDegToRad(getWord(%oldvalue, 0)+0);
			case 7: //RadToDeg
				%value = mRadToDeg(getWord(%oldvalue, 0)+0);
			case 8: //FloatLength
				%value = mFloatLength(getWord(%oldvalue, 0)+0, getWord(%newvalue, 0)+0);
			case 9: //FloorTo
				%value = mFloorTo(getWord(%oldvalue, 0)+0, (%newvalue $= "" ? 1 : getWord(%newvalue, 0)+0));
			case 10: //RoundTo
				%value = mCeilTo(getWord(%oldvalue, 0)+0, (%newvalue $= "" ? 1 : getWord(%newvalue, 0)+0));
			case 11: //CeilTo
				%value = mCeilTo(getWord(%oldvalue, 0)+0, (%newvalue $= "" ? 1 : getWord(%newvalue, 0)+0));
			case 12: //RandomInt
				%value = getRandom(mRound(getWord(%newvalue, 0)+0), mRound(getWord(%newvalue, 1)+0));
			case 13: //RandomFloat
				%value = getRandomF(getWord(%newvalue, 0)+0, getWord(%newvalue, 1)+0);
			case 14: //Interpolate
				%value = mInterpolate(%oldvalue+0, getWord(%newvalue, 0)+0, getWord(%newvalue, 1)+0);
		}
		%brick.vce_modVariable(%type, %name, 0, %value, %client); //Hacky way to allow for special var editing and whatnot, also lets packages effect these, and other crap..
	}
}

function fxDtsBrick::VCE_modVectorVar(%brick, %type, %name, %logic, %value, %client)
{
	%player = %client.player;
	if(%client.blockVCE[getBrickGroupFromObject(%brick).bl_id])
		return;

	if(isObject(%player) && getSimTime() - %player.spawnTime < $VCE::Server::ImmuneTime)
		return;

	if(isObject(%brick.getGroup().vargroup))
	{
		switch(%type)
		{
			case 0:
				%category = "Brick";
				%target = %brick;
				%class = "fxDtsBrick";
			case 1:
				%category = "Player";
				%target = %player;
				%class = "Player";
			case 2:
				%category = "Client";
				%target = %client;
				%class = "GameConnection";
			case 3:
				%category = "Minigame";
				%target = getMinigameFromObject(%brick);
				%class = "MinigameSO";
			case 4:
				%category = "Vehicle";
				%target = %brick.vehicle;
				%class = "Vehicle";
		}
		if(!isObject(%target))
			return;
		%name = filterVariableString(%name, %brick, %client, (isObject(%player) ? %player : 0));
		%oldvalue = %brick.getGroup().vargroup.getVariable(%category, %name, %target);
		%newvalue = filterVariableString(%value, %brick, %client, (isObject(%player) ? %player : 0));

		switch(%logic)
		{
			case 0: //Add
				%value = vectorAddMulti(%oldvalue, %newvalue); //Custom functions which handle up to infinite dimensional vectors decently
			case 1: //Subtract
				%value = vectorSubMulti(%oldvalue, %newvalue);
			case 2: //Scale
				%value = vectorScaleMulti(%oldvalue, %newvalue);
			case 3: //Multiply
				%value = vectorMultiplyMulti(%oldvalue, %newvalue);
			case 4: //Divide
				%value = vectorDivideMulti(%oldvalue, %newvalue);
			case 5: //Length
				%value = vectorLenMulti(%oldvalue);
			case 6: //Normalize
				%value = vectorNormalizeMulti(%oldvalue);
			case 7: //Distance
				%value = vectorDistMulti(%oldvalue, %newvalue);
			case 8: //Lerp (3d only)
				%value = vectorLerp(%oldvalue, getWords(%newvalue, 0, 2), getWord(%newvalue, 3)+0);
			case 9: //Slerp
				%value = vectorSlerp(%oldvalue, getWords(%newvalue, 0, 2), getWord(%newvalue, 3)+0);
			case 10: //AngleBetween
				%value = mRadToDeg(vectorAngleBetween(%oldvalue, %newvalue));
			case 11: //convertToAngle
				%value = vectorToEuler(%oldvalue);
			case 12: //createFromAngle
				%value = eulerToVector(%oldvalue);
			case 13: //RotateByAngle
				%value = vectorRotateEuler(getWords(%oldvalue, 0, 2), getWords(%newvalue, 0, 2));
		}
		%brick.vce_modVariable(%type, %name, 0, %value, %client); //Hacky way to allow for special var editing and whatnot, also lets packages effect these, and other crap..
	}
}

function fxDtsBrick::VCE_modStringVar(%brick, %type, %name, %logic, %value, %client)
{
	%player = %client.player;
	if(%client.blockVCE[getBrickGroupFromObject(%brick).bl_id])
		return;

	if(isObject(%player) && getSimTime() - %player.spawnTime < $VCE::Server::ImmuneTime)
		return;

	if(isObject(%brick.getGroup().vargroup))
	{
		switch(%type)
		{
			case 0:
				%category = "Brick";
				%target = %brick;
				%class = "fxDtsBrick";
			case 1:
				%category = "Player";
				%target = %player;
				%class = "Player";
			case 2:
				%category = "Client";
				%target = %client;
				%class = "GameConnection";
			case 3:
				%category = "Minigame";
				%target = getMinigameFromObject(%brick);
				%class = "MinigameSO";
			case 4:
				%category = "Vehicle";
				%target = %brick.vehicle;
				%class = "Vehicle";
		}
		if(!isObject(%target))
			return;
		%name = filterVariableString(%name, %brick, %client, (isObject(%player) ? %player : 0));
		%oldvalue = %brick.getGroup().vargroup.getVariable(%category, %name, %target);
		%newvalue = filterVariableString(%value, %brick, %client, (isObject(%player) ? %player : 0));

		switch(%logic)
		{
			case 0: //WordCount
				%value = getWordCount(%oldvalue);
			case 1: //GetWords
				%a = getWord(%newvalue, 0);
				%b = getWord(%newvalue, 1);
				if(%a <= 0)
					%a = 0;
				if(%b <= %a)
					%b = %a;
				%value = getWords(%oldvalue, %a+0, %b+0);
			case 2: //SetWord
				%value = setWord(%oldvalue, getWord(%newvalue, 0), getWords(%newvalue, 1, 9001));
			case 3: //WordIndex
				for(%i=0; %i < getWordCount(%oldvalue); %i++)
					if(getWord(%oldvalue, %i) $= %newvalue)
					{
						%value = %i;
						break;
					}
			case 4: //CharLength
				%value = strlen(%oldvalue);
			case 5: //PosOfChar
				%value = strpos(%oldvalue, %newvalue);
			case 6: //GetSubStr
				%a = getWord(%newvalue, 0);
				%b = getWord(%newvalue, 1);
				if(%a <= 0)
					%a = 0;
				if(%b <= 0)
					%b = 1;
				%value = getSubStr(%oldvalue, %a, %b);
			case 7: //GetSubStr2
				%a = getWord(%newvalue, 0);
				%b = getWord(%newvalue, 1);
				if(%a <= 0)
					%a = 0;
				if(%b <= %a)
					%b = %a+1;
				%value = getSubStr(%oldvalue, %a, %b-%a);
			case 8: //Replace
				%a = strPos(%newvalue, "::");
				if(%a == -1)
					return;
				%a = getSubStr(%newvalue, 0, %a);
				%b = getSubStr(%newvalue, strLen(%a)+2, 9001);
				%value = strReplace(%oldvalue, %a, %b);
		}
		%brick.vce_modVariable(%type, %name, 0, %value, %client); //Hacky way to allow for special var editing and whatnot, also lets packages effect these, and other crap..
	}
}

function fxDtsBrick::VCE_advModVariable(%brick,%type,%name,%logic,%value,%client)
{
	if(%client.blockVCE[getBrickGroupFromObject(%brick).bl_id] || ((isObject(%client.player) && getSimTime() - %client.player.spawnTime < $VCE::Server::ImmuneTime)))
		return;
	if(isObject(%brick.getGroup().vargroup))
	{
		switch(%type)
		{
			case 0:
				%category = "Brick";
				%target = %brick;
				%class = "fxDtsBrick";
			case 1:
				%category = "Player";
				%target = %client.player;
				%class = "Player";
			case 2:
				%category = "Client";
				%target = %client;
				%class = "GameConnection";
			case 3:
				%category = "Minigame";
				%target = getMinigameFromObject(%brick);
				%class = "MinigameSO";
			case 4:
				%category = "Vehicle";
				%target = %brick.vehicle;
				%class = "Vehicle";
		}
		%name = filterVariableString(%name,%brick,%client,%client.player);
		%oldvalue = %brick.getGroup().vargroup.getVariable(%category,%name,%target);
		%newvalue = filterVariableString(%value,%brick,%client,%client.player);
		//Removed special var editing.
		switch(%logic)
		{
			case 0:
				if(%newvalue+0 != -1)
					%value = mSin(%oldvalue+0);
				else
					%value = mAsin(%oldvalue+0);
			case 1:
				if(%newvalue+0 != -1)
					%value = mCos(%oldvalue+0);
				else
					%value = mAcos(%oldvalue+0);
			case 2:
				if(%newvalue+0 != -1)
					%value = mTan(%oldvalue+0);
				else
					%value = mAtan(getWord(%oldvalue, 0)+0, getWord(%oldvalue, 1)+0);
			case 3:
				%value = mDegToRad(%oldvalue+0);
			case 4:
				%value = mRadToDeg(%oldvalue+0);
			case 5:
				%value = mFloatLength(%oldvalue+0,%newvalue+0);
			case 6:
				%value = VectorAdd(%oldvalue,%newvalue);
			case 7:
				%value = VectorSub(%oldvalue,%newvalue);
			case 8:
				%value = VectorScale(%oldvalue,%newvalue);
			case 9:
				%value = VectorDist(%oldvalue,%newvalue);
			case 10:
				%value = VectorLen(%oldvalue);
			case 11:
				%value = VectorNormalize(%oldvalue);
			case 12:
				if(getWordCount(%newvalue) == 2)
				{
					if(getWord(%newvalue,0)+0 >= 0 && getWord(%newvalue,1)+0 >= 0)
						%value = getSubStr(%oldvalue,getWord(%newvalue,0)+0,getWord(%newvalue,1)+0);
					else
						return;
				} else if(getWordCount(%newvalue) == 1)
				{
					if(getWord(%newvalue,0)+0 >= 0)
						%value = getSubStr(%oldvalue,getWord(%newvalue,0)+0,9001);
					else
						return;
				}
			case 13:
				%value = strpos(%oldvalue, %newvalue);
		}
		%brick.vce_modVariable(%type, %name, 0, %value, %client);
	}
	%brick.onVariableUpdate(%client);
}