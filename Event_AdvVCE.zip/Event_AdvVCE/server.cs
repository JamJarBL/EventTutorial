if((%e = ForceRequiredAddOn("Event_Variables")) == $Error::None || %e == $Error::AddOn_Disabled) //Requires VCE
{
	if((%e = ForceRequiredAddOn("Event_AdvCore")) == $Error::None || %e == $Error::AddOn_Disabled)
	{
		exec("./Replacers.cs");
		exec("./AdvModVar.cs");
		exec("./Expression.cs");
		exec("./SpawnProjAdv.cs");
		//exec("./CodeTags.cs");
	}
}

function AdvVCEDebug(%msg, %a, %b, %c) {
	return advEventsDebug(%msg, %a, %b, %c);
}