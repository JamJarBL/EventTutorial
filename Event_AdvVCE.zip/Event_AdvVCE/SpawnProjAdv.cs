registerInputEvent(fxDTSBrick, "onProjectileSpawned","Self fxDTSBrick\tPlayer Player\tClient GameConnection\tProjectile Projectile\tMiniGame MiniGame");
registerInputEvent(fxDTSBrick, "onProjectileRecreated","Self fxDTSBrick\tPlayer Player\tClient GameConnection\tProjectile Projectile\tMiniGame MiniGame");
registerOutputEvent(fxDtsBrick, "spawnAdvProj", "Datablock projectileData\tstring 128 60\tstring 128 60\tstring 128 40", 1);
registerOutputEvent(Projectile, "recreate", "int 1 10 3", 1);


package AdvVCE_ProjectilePackage {
	function fxDTSBrick::spawnProjectile(%brick, %vel, %projData, %randVel, %scale, %client) {
		parent::spawnProjectile(%brick, %vel, %projData, %randVel, %scale, %client);

		//%searchPos = vectorScale(vectorAdd(getWords(%brick.getWorldBox(), 0, 2), getWords(%brick.getWorldBox(), 3, 5)), 0.5);
		%searchPos = %brick.getPosition();
		%box = %brick.getObjectBox();
		%box = vectorSub(getWords(%box, 3, 5), getWords(%box, 0, 2));
		//%box = vectorScale(%box, 0.25);

		switch(%brick.angleId)
		{
			case 1: %box = getWord(%box, 1) SPC getWord(%box, 0) SPC getWord(%box, 2);
			case 3: %box = getWord(%box, 1) SPC getWord(%box, 0) SPC getWord(%box, 2);
		}
		%box = vectorAdd(%box, "0.1 0.1 0.1");

		%mask = $TypeMasks::ProjectileObjectType;

		initContainerBoxSearch(%searchPos, %box, %mask);
		while(isObject(%obj = containerSearchNext()))
		{
			if(%obj.getDatablock() == %projData && !%obj.hasCalledOnProjectileSpawned)
			{
				%proj = %obj;
				break;
			}
		}

		if(isObject(%proj))
		{
			%proj.hasCalledOnProjectileSpawned = 1;
			%brick.onProjectileSpawned(%client, %proj);
			%proj.sourceBrick = %brick;
		}
	}
};
activatePackage(AdvVCE_ProjectilePackage);

function fxDtsBrick::spawnAdvProj(%brick, %datablock, %pos, %vel, %size, %client)
{
	%player = (isObject(%player = %client.player) ? %player : 0);
	if(isFunction(filterVariableString)) //VCE support
	{
		%pos  = filterVariableString(%pos, %brick, %client, %player);
		%vel  = filterVariableString(%vel, %brick, %client, %player);
		%size = filterVariableString(%size, %brick, %client, %player);
	}

	%pos = vectorAdd(%pos, "0 0 0");
	%vel = vectorAdd(%vel, "0 0 0");
	if(getWordCount(%size) == 1) {
		//%size = mClamp(%size, 0.01, 5); //WTF! mClamp doesnt work with floats. Really? Wow..
		%size = getMin(getMax(0.01, %size), 5);
		%size = %size SPC %size SPC %size;
	} else {
		%size = getMin(getMax(0.01, getWord(%size, 0)), 5) SPC getMin(getMax(0.01, getWord(%size, 1)), 5) SPC getMin(getMax(0.01, getWord(%size, 2)), 5);
	}

	%proj = new Projectile()
	{
		datablock = %datablock;
		initialVelocity = %vel;
		velocity = %vel;
		initialPosition = %pos;
		position = %pos;
		sourceObject = %player;
		sourceSlot = 0;
		client = %client;
	};

	if(!isObject(%proj)) {
		return;
	}

	%proj.setScale(%size);
	MissionCleanup.add(%proj);

	%brick.onProjectileSpawned(%client, %proj);
}

function fxDTSBrick::onProjectileSpawned(%brick, %client, %proj)
{
	$InputTarget_["Self"] = %brick;
	$InputTarget_["Projectile"] = %proj;
	$InputTarget_["Player"] = (isObject(%obj = %proj.sourceObject) ? %obj : (isObject(%obj = %proj.sourceClient.player) ? %obj : 0));
	$InputTarget_["Client"] = (isObject(%obj = %proj.sourceClient) ? %obj : (isObject(%obj = %proj.sourceObject.client) ? %obj : 0));

	if($Server::LAN)
		$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
	else {
		if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
			$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
		else
			$InputTarget_["MiniGame"] = 0;
	}
	//process the event
	%brick.processInputEvent("onProjectileSpawned", %client);
}

function fxDTSBrick::onProjectileRecreated(%brick, %client, %proj)
{
	$InputTarget_["Self"] = %brick;
	$InputTarget_["Projectile"] = %proj;
	$InputTarget_["Player"] = (isObject(%obj = %proj.sourceObject) ? %obj : (isObject(%obj = %proj.sourceClient.player) ? %obj : 0));
	$InputTarget_["Client"] = (isObject(%obj = %proj.sourceClient) ? %obj : (isObject(%obj = %proj.sourceObject.client) ? %obj : 0));

	if($Server::LAN)
		$InputTarget_["MiniGame"] = getMiniGameFromObject(%client);
	else {
		if(getMiniGameFromObject(%obj) == getMiniGameFromObject(%client))
			$InputTarget_["MiniGame"] = getMiniGameFromObject(%obj);
		else
			$InputTarget_["MiniGame"] = 0;
	}
	//process the event
	%brick.processInputEvent("onProjectileRecreated", %client);
}

function Projectile::recreate(%proj, %amt, %client)
{
	if(%proj.recreateCount > %amt)
		return;
	%proj.setName("ProjectileRecreateTempName");
	%newProj = new Projectile(ProjectileRecreatedTempName : ProjectileRecreateTempName)
	{
		datablock = %proj.getDatablock();
		position = %proj.getPosition();
		recreateCount = %proj.recreateCount+1;
	};

	%proj.delete();
	%newProj.setName("");

	%newProj.dump();

	%brick = %newproj.sourceObject;

	if(%newProj.recreateCount <= %amt && isObject(%brick) && %brick.getClassName() $= "fxDtsBrick")
		%brick.onProjectileRecreated(%client, %newproj);
}