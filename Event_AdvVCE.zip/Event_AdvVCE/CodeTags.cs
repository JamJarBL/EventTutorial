/////////////////////////////////////////
//Example area, so i can plan stuff out//
/////////////////////////////////////////
//write["Tests"] Write is a function, that is passed the array that contains a string that contains "Tests"
//c%asdf = 5 Numbers dont need special formatting
//5 + 21 Operators which possibly can be created, +, -, /, *, etc
//[5 2] 2d vector.
//
//Vectors are [1 2 3], arrays are [1, 2, 3]
//
// while[c%a == 5] {c%a = getRandom[5, 6]}
//
// 5 * [2 4 0] Scales
// [1 2 3] * [2 4 0] Multiplies each element in a by the corrisponding element in b
// Cross and dot products are done with functions
//
//
// () is done first, before anything.
// {} is for conditionals/loops.
// [] is for vectors/arrays/functions
// "" is for strings
//
//
//
//
//
//
// VectorCross returns vector
// VectorDot returns scalar.
//

return;
exec("./CodeTags_Misc.cs");

package advVCE_CT_package {
	function filterVariableString(%str, %brick, %client, %player, %vehicle) {
		%str = filterCTString(%str, %brick, %client);

		return parent::filterVariableString(%str, %brick, %client, %player, %vehicle);
	}
};
activatePackage(advVCE_CT_package);

function filterCTString(%str, %brick, %client) {
	while(1) {
		%tagOpenPos = strPos(%str, "<ct:");
		if(%tagOpenPos == -1)
			break;

		%tagClosePos = strpos(%str, ">", %tagOpenPos);
		%codeString = getSubStr(%str, %tagOpenPos + 4, (%tagClosePos - %tagOpenPos) - 1);
		
		%codeString = formatCTString(%codeString);
		execCTString(%codeString, %brick, %client);
	}
	return %str;
}

function formatCTString(%str) {
	return %str; //Lolnope
}

function execCTString(%str, %brick, %client) {
	echo("execCTString("@%str@");");
	%len = strLen(%str);
	for(%i=0; %i < %len; %i++) {
		%char = getSubStr(%str, %i, 1);

		if(%char $= "(") {
			if(%curvedBracketIndent++ == 1) {
				%curvedBracketPos = %i+1;
			}
		} else if(%char $= ")") {
			if(%curvedBracketIndent-- == 0) {
				%curvedBrackets = getSubStr(%str, %curvedBracketPos, %i - %curvedBracketPos);
				%curvedBrackets = execCTString(%curvedBrackets, %brick, %client);
				%str = getSubStr(%str, 0, %curvedBracketPos-1) @ %curvedBrackets @ getSubStr(%str, %i+1, 1000000);
				%i = %curvedBracketPos;
				%len = strLen(%str);
			}
		}
	}

	if(%curvedBracketIndent != 0) {
		%client.CTError("Syntax", (%curvedBracketIndent > 0 ? ")" : "(") SPC "expected", %str);
		return;
	}

	%strLen = strLen(%str);

	%lastChar = "";
	for(%i=0; %i < %strLen; %i++) {
		%char = getSubStr(%str, %i, 1);
		if(isNumber(%char) && (%char !$= "." || isNumber(%lastChar)) ) {
			
		}

		%lastChar = %char;
	}

	//Do all functions here

	for(%i=0; %i <= 5; %i++) {
		switch(%i) {
			case 0: %operators = "^";
			case 1: %operators = "* / %";
			case 2: %operators = "+ -";
			case 3: %operators = "== != << >> >= <=";
			case 4: %operators = "& |";
			case 5: %operators = "=";
		}

		%operatorsWordCount = getWordCount(%operators);

		for(%j=0; %j < %strLen; %j++) {
			for(%k=1; %k <= 2; %k++) { //Change 2 to the length of the longest operator
				%subStr = getSubStr(%str, %j, %k);
				for(%l=0; %l < %operatorsWordCount; %l++) {
					%operator = getWord(%operators, %l);
					if(%subStr $= %operator) {

					}
				}
			}
		}
	}

	echo("Out:" SPC %str);

	return %str;
}

$CodeTags::operators::functionName["^"] = "power";

function isNumber(%str) {
	return (numericWhiteListFilter(%str) $= %str);
}

function registerCTFunction(%name, %objectClass, %callback, %par1Type, %par2Type, %par3Type, %par4Type, %par5Type, %par6Type, %par7Type, %par8Type) {

}

function GameConnection::CTError(%type, %explaination, %string) {
	echo("CodeTag:" SPC %type SPC "error:" SPC %explaination);
	echo("        " SPC %string);
}

function CodeTags_getValueType(%str) {
	if(isNumber(%str))
		return "Number";
	%firstChar = getSubStr(%str, 0, 1);
	%lastChar = getSubStr(%str, strLen(%str)-2, 1);
	if(%firstChar $= "\"" && %lastChar $= "\"")
		return "String";
	if(%firstChar $= "[" && %lastChar $= "]") {
		if(strPos(%str, ",") != -1)
			return "Array";
		else
			return "Vector";
	}
}

function CodeTags_Array_getAllValueTypes(%str) {
	if(CodeTags_getValueType(%str) !$= "Array")
		return;

	%strNoComma = strReplace(getSubStr(%str, 1, strLen(%str)-2), ",", " ");
	%count = getWordCount(%strNoComma);
	for(%i=0; %i < %count; %i++) {
		%word = trim(getWord(%strNoComma, %i));
		if(%word $= "")
			continue;
		%type = CodeTags_getValueType(%word);

		if(%type $= "")
			continue;

		if(%had[%type])
			continue;
		%had[%type] = 1;

		%results = %results SPC %type;
	}
	%results = trim(%results);
	
	return %results;
}

function CodeTags_Array_getMainValueType(%str) {
	if(CodeTags_getValueType(%str) !$= "Array")
		return;

	%strNoComma = strReplace(getSubStr(%str, 1, strLen(%str)-2), ",", " ");
	%count = getWordCount(%strNoComma);
	for(%i=0; %i < %count; %i++) {
		%word = trim(getWord(%strNoComma, %i));
		if(%word $= "")
			continue;
		%type = CodeTags_getValueType(%word);

		if(%type $= "")
			continue;

		%had[%type]++;

		%results = %results SPC %type;
	}
	%results = trim(%results);
	for(%i=0; %i < getWordCount(%results); %i++) {
		%type = getWord(%results, %i);
		if(%had[%type] > %mostNum) {
			%mostNum = %had[%type];
			%mostType = %type;
		}
	}
	
	return %mostType;
}

function CT_Vector_getComponents(%str) {
	%str = getSubStr(%str, 1, strLen(%str)-2);
	%count = getWordCount(%str);
	for(%i=0; %i < %count; %i++) {
		%word = trim(getWord(%str, %i));
		if(%word $= "")
			continue;
		
		%results = %results SPC %word;
	}
	return trim(%results);
}