//PLEASE NOTE: This event is WIP, and more of a proof of concept than anything else.
//A lot of changes will be made to this event in future updates (hopefully), so dont
//get too attached! Most of the code has comments explaining how it works, incase
//anyone is interested. Also, i know its messy. Deal with it.

registerOutputEvent(fxDtsBrick,"VCE_Expression","string 128 100\tstring 128 100\tstring 128 100\tstring 128 100",1);

function fxDtsBrick::VCE_Expression(%brick,%a,%b,%c,%d,%client)
{
	if(isObject(%brick.getGroup().vargroup))
	{
		%str = %a SPC %b SPC %c SPC %d;
		%str = filterVariableString(%str,%brick,%client,%client.player);
		advEventsDebug("Preparing new string");
		advVCEDecodeString(%str, %brick, %client);
	}
	%brick.onVariableUpdate(%client);
}

function advVCEDecodeString(%str, %brick, %client)
{
	%str = trim(%str);

	advEventsDebug("Expression: Decoding String '" @ %str @ "'");

	%str = advVCEFilterString(%str, 0, getWordCount(%str)-1, %brick, %client); //Filters any x%y's and <var:x:y>'s

	%alphabet = "abcdefghijklmnopqrstuvwxyz%="; //Added % and = so =b%a etc work

	%len = strLen(%str);
	while(strPos(%str, "(") >= 0)
	{
		for(%i=0; %i < %len; %i++)
		{
			%cur = getSubStr(%str, %i, 1);

			if(%cur $= "(" )
			{
				%oBrkt[%brktCount++] = %i;
				continue;
			}

			if(%cur $= ")" )
			{
				if(%brktCount <= 0)
					return "Error: Too few open brackets!";

				%brackets = advVCEDecodeString( getSubStr(%str, %obrkt[%brktCount]+1, %i-%obrkt[%brktCount]-1), %brick, %client);
				%str = getSubStr(%str, 0, %obrkt[%brktCount]) SPC %brackets SPC getSubStr(%str, %i+1, 100000);
				%brktCount--;
				%i += strLen(%brackets)+1;
				continue;
			}
		}

		%breaker++;
		if(%breaker > 100)
		{
			//talk("Expression: Breaker > 100! Please report this to Boodals.");
			break;
		}
	}

	advEventsDebug("Expression: Stage 2 begins with '" @ %str @ "'");

	for(%i=0; %i < %len; %i++)
	{
		%cur = getSubStr(%str, %i, 1);

		if(isInt(%cur) || %cur $= "." || (%cur $= "-" && (getSubStr(%str, %i+1, 1) $= "." || isInt(getSubStr(%str, %i+1, 1)) ) ))
		{
			%numbCur = "";
			%numb = "";
			for(%j=0; %j < %len - %i; %j++)
			{
				%numbCur = getSubStr(%str, %i+%j, 1);
				if(isInt(%numbCur) || (%numbCur $= "." && strpos(%numb, ".") == -1) || (%cur $= "-" && (getSubStr(%str, %i+1, 1) $= "." || isInt(getSubStr(%str, %i+1, 1)) ) ))
					%numb = %numb @ %numbCur;
				else
					break;
			}
			%i += strLen(%numb)-1;
			%stage3 = %stage3 SPC %numb;
			continue;
		}

		if(striPos(%alphabet, %cur) >= 0) //Is letter
		{
			%numbCur = "";
			%numb = "";
			for(%j=0; %j < %len - %i; %j++)
			{
				%numbCur = getSubStr(%str, %i+%j, 1);
				if(striPos(%alphabet, %numbCur) >= 0)
					%numb = %numb @ %numbCur;
				else
					break;
			}
			%i += strLen(%numb)-1;
			%stage3 = %stage3 SPC %numb;
			continue;
		}

		if(%cur $= " ")
			continue;

		%stage3 = %stage3 SPC %cur;
	}
	%str = trim(%stage3);

	advEventsDebug("Expression: Stage 3 started with str '" @ %str @ "'");

	%count = getWordCount(%str);
	for(%i=0; %i < %count; %i++)
	{
		%prev = getWord(%str, %i-1);
		%next = getWord(%str, %i+1);
		%cur = getWord(%str, %i);

		if(!strLen(%prev)) continue;

		
		if(strpos(%cur,"=") == 0)
		{
			%this = strReplace(%cur,"=","");
			%this = AdvVCEDecodeVariable(%this,%brick,%client);
			%category = getWord(%this,0);
			%var = getWord(%this,1);
			%target = getWord(%this,2);
			advEventsDebug("Setting" SPC %var SPC "to" SPC %prev);

			switch$(%category)
			{
				case "Brick":
					%type = 0;
				case "Player":
					%type = 1;
				case "Client":
					%type = 2;
				case "Minigame":
					%type = 3;
				case "Vehicle":
					%type = 4;
			}
			%brick.VCE_modVariable(%type,%var,0,%prev,%target);
			%str = setWord(%str,%i,%prev);
		}

		if(%cur $= "+")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,%prev+%next);
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "-")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,%prev-%next);
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "*")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,%prev*%next);
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "/")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,%prev/%next);
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "^")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,mPow(%prev,%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "root")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,mPow(%prev,1/%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "sin")
		{
			%str = setWord(%str,%i,mSin(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "asin")
		{
			%str = setWord(%str,%i,mAsin(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "cos")
		{
			%str = setWord(%str,%i,mCos(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "acos")
		{
			%str = setWord(%str,%i,mAcos(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "tan")
		{
			%str = setWord(%str,%i,mTan(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "atan")
		{
			if(!strLen(%prev)) continue;
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,mAtan(%prev,%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "degToRad")
		{
			%str = setWord(%str,%i,mDegToRad(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "radToDeg")
		{
			%str = setWord(%str,%i,mRadToDeg(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "floatLength")
		{
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,mFloatLength(%prev,%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "random" || %cur $= "rand")
		{
			if(!strLen(%prev)) continue;
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,getRandom(%prev,%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "mod" || %cur $= "%")
		{
			%str = setWord(%str,%i+1, mMod(%prev, %next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "floor")
		{
			%str = setWord(%str,%i,mFloor(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "ceil")
		{
			%str = setWord(%str,%i,mCeil(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "round")
		{
			%str = setWord(%str,%i,mRound(%prev));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
		}
		if(%cur $= "min")
		{
			if(!strLen(%prev)) continue;
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,getMin(%prev,%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
		if(%cur $= "max")
		{
			if(!strLen(%prev)) continue;
			if(!strLen(%next)) continue;
			%str = setWord(%str,%i+1,getMax(%prev,%next));
			%str = removeWord(%str, %i-1);
			%i--;
			%count--;
			%str = removeWord(%str, %i);
			%i--;
			%count--;
		}
	}

	advEventsDebug("Expression: Returned" SPC %str);
	return %str;
}

function advVCEFilterString(%str, %w, %e, %brick, %client) //String, First word, Last word, Brick, Client
{
	advEventsDebug("Filtering string from word" SPC %w SPC "to" SPC %e);
	for(%w; %w<%e; %w++)
	{
		%cur = getWord(%str,%w);
		if(strpos(%cur,"%") != -1 && strpos(%cur,"=") == -1)
		{
			%this = advVCEDecodeVariable(%cur,%brick,%client);
			if(getWordCount(%this) != 3)
			{
				advEventsDebug("Failed to decode string" SPC %cur);
				continue;
			}
			%category = getWord(%this,0);
			%var = getWord(%this,1);
			%target = getWord(%this,2);
			%cur = filterVariableString("<var:" @ %category @ ":" @ %var @ ">",%brick,%client,%player,(isObject(%v = %brick.vehicle) ? %v : 0));

			advEventsDebug("Decoded variable into" SPC %cur);
			%str = setWord(%str,%w,%cur);
			advEventsDebug("String filtered to" SPC %cur);
		}
	}
	return %str;
}

function advVCEDecodeVariable(%cur,%brick,%client) //Word, Brick, Client
{
	%afterSign = strchr(%cur,"%");
	%var = strreplace(%afterSign,"%","");
	%tar = strreplace(%cur,%aftersign,"");
	if(%var $= "")
		return false;
	if(%tar $= "Self" || %tar $= "S" || %tar $= "Brick" || %tar $= "B")
	{
		%target = %brick;
		%category = "Brick";
	} else if(%tar $= "Player" || %tar $= "P")
	{
		%target = %client.player;
		%category = "Player";
	} else if(%tar $= "Client" || %tar $= "C" || %tar $= "")
	{
		%target = %client;
		%category = "Client";
	} else if(%tar $= "Minigame" || %tar $= "Mini" || %tar $= "M")
	{
		%target = getMinigameFromObject(%brick);
		%category = "Minigame";
	} else if(%tar $= "Vehicle" || %tar $= "V")
	{
		%target = %brick.vehicle;
		%category = "Vehicle";
	} else {
		return false;
	}
	advEventsDebug("Decoded" SPC %cur SPC "into: '" @ %category @ "' '" @ %var @ "' '" @ %target @ "'");
	return %category SPC %var SPC %target;
}