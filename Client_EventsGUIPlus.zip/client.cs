//****************************
//  EventsGUIplus
//
//    Clockturn
//    Truce
//****************************

$EventsGUIplus::FilePath = "config/client/eventSaves";
$EventsGUIplus::CloseAfterOp = 1;
$EventsGUIplus::LoadIncompleteEvents = 0;
$EventsGUIplus::ShowHideInstant = 0;
$EventsGUIplus::ShowInvalidSaves = 1;
if(isFile("config/client/EventsGuiPlus.cs"))
{
	exec("config/client/EventsGUIplus.cs");
}
export("$EventsGUIplus::*","config/client/EventsGUIplus.cs");

exec("./Saver.cs");
exec("./Mover.cs");

// Core functions
function WrenchEventsDlg::showStatus(%gui,%status)
{
	if(!isObject(EGplus_Ticker))
	{
		return;
	}
	if(EGplus_Ticker.statusCount $= "")
	{
		EGplus_Ticker.statusCount = 0;
	}
	EGplus_Ticker.status[EGplus_Ticker.statusCount] = %status;
	%len = strlen(stripMLcontrolChars(%status));
	%delay = mFloor(strlen(stripMLcontrolChars(%status))/10) * 500;
	EGplus_Ticker.statusDelay[EGplus_Ticker.statusCount] = %delay;
	EGplus_Ticker.statusCount++;
	if(!isEventPending(EGplus_Ticker.ShowStatus))
	{
		EGplus_Ticker.ShowStatus();
	}
}
function EGplus_Ticker::showStatus(%ticker)
{
	cancel(%ticker.hide);
	cancel(%ticker.showStatus);
	%ticker.setText(%ticker.status[0]);
	%delay = %ticker.statusDelay[0];
	if(%ticker.statusCount > 0)
	{
		for(%i=0;%i<%ticker.statusCount;%i++)
		{
			%ticker.status[%i] = %ticker.status[%i+1];
			%ticker.statusDelay[%i] = %ticker.statusDelay[%i+1];
		}
		%ticker.statusCount--;
		%ticker.showStatus = %ticker.schedule(%delay,"showStatus");
	} else {
		%ticker.hide = %ticker.schedule(%delay,"clear");
	}
}
function EGplus_Ticker::clear(%ticker)
{
	cancel(%ticker.hide);
	cancel(%ticker.showStatus);
	for(%i=0;%i<%ticker.statusCount;%i++)
	{
		%ticker.status[%i] = "";
		%ticker.statusDelay[%i] = "";
	}
	%ticker.statusCount = 0;
	%ticker.setText("");
}
package EGplus_Core
{
	function WrenchEventsDlg::onSleep(%gui)
	{
		EGplus_Ticker.clear();
		export("$EventsGUIplus::*","config/client/EventsGUIplus.cs");
		Parent::onSleep(%gui);
	}
	function WrenchEventsDlg::onWake(%gui)
	{
		$EventsGuiWakingRightNowAndMakingConsoleSpamIfIDoThis = 1;
		EGplus_Main.close(1);
		EGPlus_Refresh();
		Parent::onWake(%gui);
		$EventsGuiWakingRightNowAndMakingConsoleSpamIfIDoThis = 0;
	}
};
ActivatePackage(EGplus_Core);

// Gui Functions
function WrenchEventsDlg::showHidePlus(%gui)
{
	if(EGplus_Main.open == 1)
	{
		EGplus_Showhide.setActive(0);
		EGplus_Showhide.text = "...";
		EGplus_Main.close($EventsGUIplus::ShowHideInstant);
	} else if(EGplus_Main.open == 0) {
		EGplus_Showhide.setActive(0);
		EGplus_Showhide.text = "...";
		EGplus_Main.open($EventsGUIplus::ShowHideInstant);
	}
}
function EGplus_Main::open(%swatch,%instant)
{
	if(%instant)
	{
		%size = getWord(%swatch.extent,1) - 276;
		%swatch.position = getWord(%swatch.position,0) SPC getWord(%swatch.position,1) + %size;
		%swatch.extent = getWord(%swatch.extent,0) SPC getWord(%swatch.extent,1) - %size;
		%swatch.open = 1;
		EGplus_Showhide.setActive(1);
		EGplus_Showhide.text = "Hide";
		return;
	}
	if(isEventPending(%swatch.Tick))
	{
		return;
	}
	if(getWord(%swatch.extent,1) < 66 || getWord(%swatch.extent,1) > 226)
	{
		%offset = 5;
	} else {
		%offset = 10;
	}
	if(getWord(%swatch.extent,1) < 276)
	{
		%swatch.position = getWord(%swatch.position,0) SPC getWord(%swatch.position,1) - %offset;
		%swatch.extent = getWord(%swatch.extent,0) SPC getWord(%swatch.extent,1) + %offset;
		%swatch.Tick = %swatch.schedule(10,"open");
		%swatch.open = -1;
	} else {
		%swatch.open = 1;
		EGplus_Showhide.setActive(1);
		EGplus_Showhide.text = "Hide";
	}
}
function EGplus_Main::close(%swatch,%instant)
{
	if(%instant)
	{
		%size = getWord(%swatch.extent,1) - 26;
		%swatch.position = getWord(%swatch.position,0) SPC getWord(%swatch.position,1) + %size;
		%swatch.extent = getWord(%swatch.extent,0) SPC getWord(%swatch.extent,1) - %size;
		%swatch.open = 0;
		EGplus_Showhide.setActive(1);
		EGplus_Showhide.text = "Show";
		return;
	}
	if(isEventPending(%swatch.Tick))
	{
		return;
	}
	if(getWord(%swatch.extent,1) < 66 || getWord(%swatch.extent,1) > 226)
	{
		%offset = 5;
	} else {
		%offset = 10;
	}
	if(getWord(%swatch.extent,1) > 26)
	{
		%swatch.position = getWord(%swatch.position,0) SPC getWord(%swatch.position,1) + %offset;
		%swatch.extent = getWord(%swatch.extent,0) SPC getWord(%swatch.extent,1) - %offset;
		%swatch.Tick = %swatch.schedule(10,"close");
		%swatch.open = -1;
	} else {
		%swatch.open = 0;
		EGplus_Showhide.setActive(1);
		EGplus_Showhide.text = "Show";
	}
}

// More GUI functions
function EGplus_Load()
{
	%id = EGplus_Main.list.getSelectedID();
	if(%id == -1)
	{
		WrenchEventsDlg.ShowStatus("<color:FF5555>No file is selected.");
		return;
	}
	%file = EGplus_Main.list.getRowTextByID(%id);
	if(%file $= "New...")
	{
		return;
	}
	WrenchEventsDlg.loadEvents(%file);
}
function EGplus_Save()
{
	%id = EGplus_Main.list.getSelectedID();
	if(%id == -1)
	{
		return;
	}
	%file = EGplus_Main.list.getRowTextByID(%id);
	if(%file $= "New...")
	{
		EGplus_FileInput.setVisible(1);
		EGplus_FileInput.setActive(1);
		return;
	}
	WrenchEventsDlg.saveEvents(%file);
}
function EGplus_MenuClick()
{
	%id = EGplus_Main.list.getSelectedID();
	%name = EGplus_Main.list.getRowTextByID(%id);
	if(%name $= "New...")
	{
		EGplus_FileInput.setVisible(1);
	} else {
		EGplus_Load();
	}
}
function EGplus_SaveNew()
{
	%name = EGplus_FileInput.getValue();
	if(isFile($EventsGUIplus::FilePath @ "/" @ %name @ ".txt"))
	{
		WrenchEventsDlg.ShowStatus("<color:FF5555>Cannot save to" SPC %name @ ".txt: File exists.");
	} else {
		WrenchEventsDlg.saveEvents(%name);
	}
	EGplus_FileInput.setValue("");
	EGplus_FileInput.setVisible(0);
}
function EGplus_Delete()
{
	%id = EGplus_Main.list.getSelectedID();
	if(%id == -1 || %id == 0)
	{
		WrenchEventsDlg.ShowStatus("<color:FF5555>Select a file to delete.");
	} else {
		%file = $EventsGUIplus::FilePath @ "/" @ EGplus_Main.list.getRowTextByID(%id) @ ".txt";
		if(isFile(%file))
		{
			fileDelete(%file);
			WrenchEventsDlg.ShowStatus("<color:55FF55>Deleted file" SPC fileName(%file));
		} else {
			WrenchEventsDlg.ShowStatus("<color:FF5555>Could not delete file: Not found (" @ fileName(%file) @ ")");
		}
	}
	EGplus_Refresh();
}
function EGplus_Refresh()
{
	%sel = EGplus_Main.list.getRowTextByID(EGplus_Main.list.getSelectedID());
	if(%sel $= "")
	{
		%sel = "New...";
	}
	EGplus_Main.list.clear();
	%file = findFirstFile($EventsGUIplus::FilePath @ "/*.txt");
	while(%file !$= "")
	{
		if(!$EventsGUIplus::ShowInvalidSaves)
		{
			if(!EGplus_CheckSave(fileBase(%file),0))
			{
				%file = findNextFile($EventsGUIplus::FilePath @ "/*.txt");
				continue;
			}
		}
		if(fileBase(%file) $= %sel)
		{
			%selidx = EGplus_Main.list.rowCount()+1;
		}
		EGplus_Main.list.addRow(EGplus_Main.list.rowCount()+1,fileBase(%file),EGplus_Main.list.rowCount()+1);
		%file = findNextFile($EventsGUIplus::FilePath @ "/*.txt");
	}
	EGplus_Main.list.sort(0);
	EGplus_Main.list.addRow(0,"New...",0);
	EGplus_Main.list.setSelectedByID(%selidx);
}

function EGplus_Funcbar::onUrl(%bar,%url)
{
	if(isFunction("EGplus_" @ %url))
	{
		call("EGplus_" @ %url);
	}
}

if(!$EventsGUIplus_Init)
{
	$EventsGUIplus_Init = 1;
	%main = new GuiSwatchCtrl(EGplus_Main) {
		profile = "GuiDefaultProfile";
		horizSizing = "center";
		vertSizing = "top";
		position = "210 294";
		extent = "480 276";
		minExtent = "8 2";
		visible = "1";
		color = "0 0 0 56";
		open = 1;
	};
	%bgswatch = new GuiSwatchCtrl() {
		profile = "GuiDefaultProfile";
		horizSizing = "center";
		vertSizing = "top";
		position = "160 570";
		extent = "480 21";
		minExtent = "8 2";
		visible = "1";
		color = "0 0 0 56";
	};
	%scroll = new GuiScrollCtrl() {
		profile = "ColorScrollProfile";
		horizSizing = "center";
		vertSizing = "top";
		position = "1 28";
		extent = "478 212";
		minExtent = "8 2";
		visible = "1";
		willFirstRespond = "1";
		hScrollBar = "alwaysOff";
		vScrollBar = "dynamic";
		constantThumbHeight = "0";
		childMargin = "0 0";
		rowHeight = "40";
		columnWidth = "30";
	};
	%list = new GuiTextListCtrl() {
		profile = "GuiTextListProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "0 0";
		extent = "377 2";
		minExtent = "8 2";
		visible = "1";
		altCommand = "EGplus_MenuClick();";
		enumerate = "0";
		resizeCell = "1";
		columns = "0";
		fitParentWidth = "1";
		clipColumnText = "0";
	};
	%funcbar = new GuiMLTextCtrl(EGplus_Funcbar) {
		profile = "BlockChatTextSize1Profile";
		horizSizing = "center";
		vertSizing = "top";
		position = "4 242";
		extent = "372 18";
		minExtent = "8 2";
		visible = "1";
		lineSpacing = "2";
		allowColorChars = "0";
		maxChars = "-1";
		text = "<just:center><color:AAAAAA><linkcolor:FFFFFF><a:Load>Load</a> - <a:Save>Save</a> - <a:Delete>Delete</a>";
		maxBitmapHeight = "-1";
		selectable = "1";
	};
	%ticker = new GuiMLTextCtrl(EGplus_Ticker) {
		profile = "BlockChatTextSize1Profile";
		horizSizing = "center";
		vertSizing = "top";
		position = "4 5";
		extent = "472 18";
		minExtent = "8 2";
		visible = "1";
		lineSpacing = "2";
		allowColorChars = "0";
		maxChars = "-1";
		text = "";
		maxBitmapHeight = "-1";
		selectable = "1";
		statusCount = 0;
	};
	%button = new GuiBitmapButtonCtrl(EGplus_Showhide) {
		profile = "BlockButtonProfile";
		horizSizing = "center";
		vertSizing = "top";
		position = "323 570";
		extent = "140 18";
		minExtent = "8 2";
		visible = "1";
		command = "WrenchEventsDlg.showHidePlus();";
		text = "Hide";
		groupNum = "-1";
		buttonType = "PushButton";
		bitmap = "base/client/ui/button1";
		lockAspectRatio = "0";
		alignLeft = "0";
		overflowImage = "0";
		mKeepCached = "0";
		mColor = "255 255 255 255";
	};
	%fileinput = new GuiTextEditCtrl(EGplus_FileInput) {
		profile = "GuiTextEditProfile";
		horizSizing = "width";
		vertSizing = "bottom";
		position = "0 0";
		extent = "478 18";
		minExtent = "8 2";
		visible = "0";
		altcommand = "EGplus_SaveNew();";
		text = "";
		maxLength = "64";
		validate = "";
		escapeCommand = "EGplus_FileInput.setValue(\"\"); EGplus_FileInput.setVisible(0);";
		historySize = 0;
		password = 0;
	};
	%applyallbutton = new GuiBitmapButtonCtrl() {
		profile = "BlockButtonProfile";
		horizSizing = "center";
		vertSizing = "top";
		position = "110 299";
		extent = "76 22";
		minExtent = "8 2";
		visible = "1";
		command = "WrenchEventsDlg.Send(); WrenchDlg.Send();";
		text = "Apply All";
		groupNum = "-1";
		buttonType = "PushButton";
		bitmap = "base/client/ui/button1";
		lockAspectRatio = "0";
		alignLeft = "0";
		overflowImage = "0";
		mKeepCached = "0";
		mColor = "255 255 255 255";
	};
	%scroll.add(%list);
	%scroll.add(%fileinput);
	%main.add(%scroll);
	%main.list = %list;
	%main.funcbar = %funcbar;
	%main.add(%funcbar);
	%main.add(%ticker);
	Wrench_Window.add(%applyallbutton);
	WrenchEvents_Window.add(%main);
	WrenchEvents_Window.add(%bgswatch);
	WrenchEvents_Window.add(%button);

	// H4X0R scroll method?
	%hacklist = new GuiMLTextCtrl(EGplus_EventMoveScroll) {
		profile = "GuiMLTextProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "0 0";
		extent = "1 39";
		minExtent = "1 39";
		visible = "1";
		altCommand = "";
		maxchars = -1;
		maxbitmapheight = -1;
		selectable = 0;
		allowcolorchars = 0;
		linespacing = 2;
		accelerator = "";
		text = "<font:Impact:40pt><tag:0>";
	};
	WrenchEvents_Scroll.add(%hacklist);
}