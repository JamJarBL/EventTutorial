package EGplus_Movement
{
	function WrenchEventsDlg::newEvent(%gui)
	{
		Parent::newEvent(%gui);
		%event = WrenchEvents_Box.getObject(WrenchEvents_Box.getCount() - 1);
		%posx = getWord(%event.position,0);
		%posy = getWord(%event.position,1);
		%uparrow = new GuiBitmapButtonCtrl() {
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "top";
			position = %posx + 3 SPC %posy + 18;
			extent = "14 14";
			minExtent = "14 14";
			visible = "1";
			command = "WrenchEventsDlg.moveEventUp(" @ %event @ ");";
			text = "";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "./img/buttonup";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			mKeepCached = "0";
			mColor = "255 255 255 255";
		};
		%dnarrow = new GuiBitmapButtonCtrl() {
			profile = "BlockButtonProfile";
			horizSizing = "right";
			vertSizing = "top";
			position = %posx + 20 SPC %posy + 18;
			extent = "14 14";
			minExtent = "14 14";
			visible = "1";
			command = "WrenchEventsDlg.moveEventDn(" @ %event @ ");";
			text = "";
			groupNum = "-1";
			buttonType = "PushButton";
			bitmap = "./img/buttondn";
			lockAspectRatio = "0";
			alignLeft = "0";
			overflowImage = "0";
			mKeepCached = "0";
			mColor = "255 255 255 255";
		};
		WrenchEvents_Scroll.add(%uparrow);
		WrenchEvents_Scroll.add(%dnarrow);
		%event.upArrow = %uparrow;
		%event.dnArrow = %dnarrow;
		%upArrow.setActive(0);
		%dnArrow.setActive(0);
		%event.scrollid = %event.getObject(0).text;
		if(!$EventsGuiWakingRightNowAndMakingConsoleSpamIfIDoThis)
		{
			WrenchEventsDlg.schedule(0,"redrawEvents");
		}
	}
	function WrenchEventsDlg::clear(%gui)
	{
		Parent::clear(%gui);
		EGplus_EventMoveScroll.clear();
		WrenchEvents_Scroll.add(EGplus_EventMoveScroll);
	}
};
ActivatePackage(EGplus_Movement);

function WrenchEventsDlg::moveEventUp(%gui,%event)
{
	%id = %event.getObject(0).text;
	if(%id == 0 || %id >= WrenchEvents_Box.getCount())
	{
		return;
	}
	setPushBack(WrenchEvents_Box,%event);
	WrenchEventsDlg.redrawEvents(%event.scrollid);
}
function WrenchEventsDlg::moveEventDn(%gui,%event)
{
	%id = %event.getObject(0).text;
	if(%id >= WrenchEvents_Box.getCount()-2)
	{
		return;
	}
	setBringForward(WrenchEvents_Box,%event);
	WrenchEventsDlg.redrawEvents(%event.scrollid+2);
}
function setPushBack(%list,%pushobj)
{
	%count = %list.getCount();
	for(%i=0;%i<%count;%i++)
	{
		%objs[%i] = %list.getObject(%i);
		if(%objs[%i] == %pushobj)
		{
			%a = %pushobj;
			%b = %objs[%i-1];
			%objs[%i-1] = %a;
			%objs[%i] = %b;
		}
	}
	%list.clear();
	for(%i=0;%i<%count;%i++)
	{
		%list.add(%objs[%i]);
	}
}
function setBringForward(%list,%pushobj)
{
	%count = %list.getCount();
	for(%i=0;%i<%count;%i++)
	{
		%objs[%i] = %list.getObject(%i);
		if(%objs[%i-1] == %pushobj && !%moved)
		{
			%a = %pushobj;
			%b = %objs[%i];
			%objs[%i-1] = %b;
			%objs[%i] = %a;
			%moved = 1;
		}
	}
	%list.clear();
	for(%i=0;%i<%count;%i++)
	{
		%list.add(%objs[%i]);
	}
}
function WrenchEventsDlg::redrawEvents(%gui,%scrollto)
{
	WrenchEvents_Scroll.scrollToTop();
	EGplus_EventMoveScroll.setText("<font:Impact:40pt><tag:0>");
	WrenchEvents_Scroll.add(EGplus_EventMoveScroll);
	EGplus_EventMoveScroll.position = "0 0";
	EGplus_EventMoveScroll.setVisible(1);
	for(%i=0;%i<WrenchEvents_Box.getCount();%i++)
	{
		if(%i > 0)
		{
			EGplus_EventMoveScroll.addText("<br><tag:" @ %i @ ">",1);
		}
		%event = WrenchEvents_Box.getObject(%i);
		%event.position = 0 SPC %i*39;
		%event.upArrow.position = 3 SPC getWord(%event.position,1) + 18;
		%event.dnArrow.position = 20 SPC getWord(%event.position,1) + 18;
		%event.getObject(0).text = %i;
		%event.scrollid = %i;
		%event.upArrow.setActive(1);
		%event.dnArrow.setActive(1);
		if(%i == 0 || %i == WrenchEvents_Box.getCount() - 1)
		{
			%event.upArrow.setActive(0);
		}
		if(%i >= WrenchEvents_Box.getCount() - 2)
		{
			%event.dnArrow.setActive(0);
		}
	}
	EGplus_EventMoveScroll.forceReflow();
	if(%scrollto !$= "")
	{
		EGplus_EventMoveScroll.schedule(0,"scrollToTag",%scrollto);
	} else {
		WrenchEvents_Scroll.schedule(0,"scrolltobottom");
	}
}