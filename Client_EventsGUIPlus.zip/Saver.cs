$EventsGUIplus_Saver_Version = 0.1;
//****************************
//  Saver
//    0.4
//    Clockturn
//  +References: Truce
//****************************

// Support Functions
function findInputEvent(%event)
{
	for(%i=0;%i<$InputEvent_Count[fxDTSbrick];%i++)
	{
		if($InputEvent_Name[fxDTSbrick,%i] $= %event)
		{
			return %i;
		}
	}
	return -1;
}
function findOutputEvent(%class,%event)
{
	for(%i=0;%i<$OutputEvent_Count[%class];%i++)
	{
		if($OutputEvent_Name[%class,%i] $= %event)
		{
			return %i;
		}
	}
	return -1;
}
function findNTname(%name)
{
	%name = "_" @ %name;
	for(%i=0;%i<ServerConnection.NTnameCount;%i++)
	{
		if(ServerConnection.NTname[%i] $= %name)
		{
			return %i;
		}
	}
	return -1;
}
function matchColor(%color)
{
	for(%i=0;%i<$Paint_numPaintRows;%i++)
	{
		%count += $Paint_Row[%i].numSwatches;
	}
	for(%i=0;%i<%count-8;%i++)
	{
		%test = getColorIDtable(%i);
		%rcon = mAbs(getWord(%color,0) - getWord(%test,0));
		%gcon = mAbs(getWord(%color,1) - getWord(%test,1));
		%bcon = mAbs(getWord(%color,2) - getWord(%test,2));
		%score = %rcon + %gcon + %bcon;
		if(%best $= "" || %score < %best)
		{
			%best = %score;
			%bestid = %i;
		}
	}
	return %bestid;
}

// Core functions:
//  SaveEvents, LoadEvents
function WrenchEventsDlg::SaveEvents(%gui,%filename)
{
	%FO = new FileObject();
	%FO.openForWrite($EventsGUIplus::FilePath @ "/" @ %filename @ ".txt");
	%FO.writeLine("# Event Saver v" @ $EventsGUIplus_Saver_Version SPC "-" SPC getDateTime());
	%count = WrenchEvents_Box.getCount()-1;
	for(%i=0;%i<%count;%i++)
	{
		%offset = 3;
		%event = WrenchEvents_Box.getObject(%i);
		%enabled = ((%event.getObject(0).getValue()) ? "X" : "-");
		%delay = %event.getObject(1).getValue() @ "ms";
		%input = %event.getObject(2).getValue();
		%inputIdx = findInputEvent(%input);
		if(%inputIdx == -1)
		{
			WrenchEventsDlg.ShowStatus("<color:FF5555>Error in saving: Input event nonexistant (" @ %input SPC "at event" SPC %i @ ")");
			%FO.writeLine("# Error in saving: Input event nonexistant.");
			%numerrors++;
			continue;
		}
		%target = %event.getObject(3).getValue();
		if(%target $= "<NAMED BRICK>")
		{
			%targetnt = %event.getObject(4).getValue();
			%target = "ID" SPC %targetnt;
			%offset++;
			%classname = "fxDTSbrick";
		} else {
			for(%x=0;%x<getFieldCount($InputEvent_TargetList[fxDTSbrick,%inputIdx]);%x++)
			{
				if(getWord(getField($InputEvent_TargetList[fxDTSbrick,%inputIdx],%x),0) $= %target)
				{
					%classname = getWord(getField($InputEvent_TargetList[fxDTSbrick,%inputIdx],%x),1);
					break;
				}
			}
			if(%classname $= "")
			{
				WrenchEventsDlg.ShowStatus("<color:FF5555>Error in saving: Target type not found (" @ %target SPC "at event" SPC %i @ ")");
				%FO.writeLine("# Error in saving: Target class nonexistant.");
				%numerrors++;
				continue;
			}
		}
		%output = %event.getObject(%offset+1).getValue();
		%outputIdx = findOutputEvent(%classname,%output);
		if(%outputIdx == -1)
		{
			WrenchEventsDlg.ShowStatus("<color:FF5555>Error in saving: Output event nonexistant (" @ %output SPC "at event" SPC %i @ ")");
			%FO.writeLine("# Error in saving: Output event nonexistant.");
			%numerrors++;
			continue;
		}
		%paramOffset = %offset+1;
		%line = %enabled SPC %delay TAB %input TAB %target TAB %output;
		for(%x=0;%x<getFieldCount($OutputEvent_ParameterList[%classname,%outputIdx]);%x++)
		{
			%add = "";
			%param = getField($OutputEvent_ParameterList[%classname,%outputIdx],%x);
			%paramtype = getWord(%param,0);
			switch$(%paramtype)
			{
			case "datablock":
				%add = %event.getObject(%paramOffset++).getValue();
			case "vector":
				%vec = %event.getObject(%paramOffset++);
				%add = %vec.getObject(0).getValue() SPC %vec.getObject(1).getValue() SPC %vec.getObject(2).getValue();
			case "bool":
				%add = ((%event.getObject(%paramOffset++).getValue()) ? "X" : "-");
			case "paintcolor":
				%add = getColorIDtable(%event.getObject(%paramOffset++).value);
			default:
				%add = %event.getObject(%paramOffset++).getValue();
			}
			%line = %line TAB %add;
		}
		%FO.writeLine(%line);
		%numsaved++;
	}
	%FO.close();
	%FO.delete();
	WrenchEventsDlg.FinishSaving(%filename,%numevents,%numerrors);
}
function WrenchEventsDlg::FinishSaving(%gui,%filename,%numevents,%numerrors)
{
	EGplus_Refresh();
	if($EventsGUIplus::CloseAfterOp)
	{
		EGplus_Main.close($EventsGUIplus::ShowHideInstant);
	}
	WrenchEventsDlg.ShowStatus("<color:55FF55>Saved" SPC %numevents SPC "to" SPC %filename @ ".txt" @ ((%numerrors != 0) ? " (" @ %numerrors SPC "errors)" : ""));
}
function WrenchEventsDlg::LoadEvents(%gui,%filename)
{
	if(isFile($EventsGUIplus::FilePath @ "/" @ %filename @ ".txt"))
	{
		if(!$EventsGUIplus::LoadIncompleteEvents)
		{
			%loadable = EGplus_CheckSave(%filename,1);
			if(!%loadable)
			{
				return;
			}
		}
		%FO = new FileObject();
		%FO.openForRead($EventsGUIplus::FilePath @ "/" @ %filename @ ".txt");
		WrenchEventsDlg.clear();
		%eventid = -1;
		while(!%FO.isEOF())
		{
			%line = %FO.readLine();
			if(getsubstr(%line,0,1) $= "#")
			{
				continue;
			}
			%eventid++;
			%enabled = (getWord(getField(%line,0),0) $= "X");
			%delay = getsubstr(getWord(getField(%line,0),1),0,strpos(getWord(getField(%line,0),1),"ms"));
			if(!isInt(%delay))
			{
				WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Delay value invalid (" @ %delay SPC "at event" SPC %eventid @ ")");
				%numerrors++;
				continue;
			}
			%input = getField(%line,1);
			%inputIdx = findInputEvent(%input);
			if(%inputIdx == -1)
			{
				WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Input event nonexistant (" @ %input SPC "at event" SPC %eventid @ ")");
				%numerrors++;
				continue;
			}
			%target = getField(%line,2);
			if(getWord(%target,0) $= "ID")
			{
				%targetname = getWords(%target,1);
				%targetnameIdx = findNTname(%targetname);
				if(%targetnameIdx == -1)
				{
					WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: NT Name missing (" @ %targetname SPC "at event" SPC %eventid @ ")");
					%numerrors++;
					continue;
				}
				%target = "<NAMED BRICK>";
				%classname = "fxDTSbrick";
			} else {
				for(%x=0;%x<getFieldCount($InputEvent_TargetList[fxDTSbrick,%inputIdx]);%x++)
				{
					if(getWord(getField($InputEvent_TargetList[fxDTSbrick,%inputIdx],%x),0) $= %target)
					{
						%classname = getWord(getField($InputEvent_TargetList[fxDTSbrick,%inputIdx],%x),1);
						break;
					}
				}
				if(%classname $= "")
				{
					WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Target type not found (" @ %target SPC "at event" SPC %eventid @ ")");
					%numerrors++;
					continue;
				}
			}
			%output = getField(%line,3);
			%outputIdx = findOutputEvent(%classname,%output);
			if(%outputIdx == -1)
			{
				WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Output event nonexistant (" @ %output SPC "at event" SPC %eventid @ ")");
				%numerrors++;
				continue;
			}
			%params = 0;
			for(%i=4;%i<getFieldCount(%line);%i++)
			{
				%param[%params] = getField(%line,%i);
				%params++;
			}
			%event = WrenchEvents_Box.getObject(WrenchEvents_Box.getCount() - 1);
			%event.getObject(0).setValue(%enabled);
			%event.getObject(1).setValue(%delay);
			%find = %event.getObject(2).findText(%input);
			if(%find != -1)
			{
				%event.getObject(2).setSelected(%find);
				%event.getObject(3).forceClose();
				%find = %event.getObject(3).findText(%target);
				if(%find != -1 || %target $= "<NAMED BRICK>")
				{
					%event.getObject(3).setSelected(%find);
					if(%target $= "<NAMED BRICK>")
					{
						%event.getObject(4).forceClose();
						%name = %event.getObject(4).findText(%targetname);
						if(%name != -1)
						{
							%event.getObject(4).setSelected(%name);
						}
						%x = 1;
					} else {
						%x = 0;
					}
					%event.getObject(4+%x).forceClose();
					%find = %event.getObject(4+%x).findText(%output);
					if(%find != -1)
					{
						%event.getObject(4+%x).setSelected(%find);
						%x++;
						%paramlist = $OutputEvent_ParameterList[%classname,%outputIdx];
						for(%i=0;%i<%params;%i++)
						{
							switch$(getWord(getField(%paramlist,%i),0))
							{
							case "datablock":
								%event.getObject(4+%x+%i).forceClose();
								%find = %event.getObject(4+%x+%i).findText(%param[%i]);
								if(%find != -1)
								{
									%event.getObject(4+%x+%i).setSelected(%find);
								}
							case "list":
								%event.getObject(4+%x+%i).forceClose();
								%find = %event.getObject(4+%x+%i).findText(%param[%i]);
								if(%find != -1)
								{
									%event.getObject(4+%x+%i).setSelected(%find);
								}
							case "paintcolor":
								%color = matchColor(%param[%i]);
								%event.getObject(4+%x+%i).value = %color;
								%event.getObject(4+%x+%i).setColor(getColorIDTable(%color));
							case "vector":
								for(%t=0;%t<3;%t++)
								{
									%event.getObject(4+%x+%i).getObject(%t).setValue(getWord(%param[%i],%t));
								}
							default:
								%event.getObject(4+%x+%i).setValue(%param[%i]);
							}
						}
						%numevents++;
					}
				}
			}
		}
		%FO.close();
		%FO.delete();
		WrenchEventsDlg.FinishLoading(%filename,%numevents,%numerrors);
	} else {
		WrenchEventsDlg.ShowStatus("<color:FF5555>Could not load from" SPC %filename @ ".txt - file not found.");
	}
}
function EGplus_CheckSave(%name,%showoutput)
{
	%file = $EventsGUIplus::FilePath @ "/" @ %name @ ".txt";
	if(!isFile(%file))
	{
		return 0;
	}
	%FO = new FileObject();
	%FO.openForRead(%file);
	%ret = 1;
	%eventid = -1;
	while(!%FO.isEOF())
	{
		%classname = "";
		%line = %FO.readLine();
		if(getsubstr(%line,0,1) $= "#")
		{
			continue;
		}
		%eventid++;
		%input = getField(%line,1);
		%target = getField(%line,2);
		%output = getField(%line,3);
		%inputIdx = findInputEvent(%input);
		if(%inputIdx == -1)
		{
			if(%showoutput)
			{
				WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Input event nonexistant (" @ %input SPC "at event" SPC %eventid @ ")");
			}
			%ret = 0;
			continue;
		}
		if(getWord(%target,0) $= "ID")
		{
			%target = getWord(%target,1);
			if(findNTname(%target) == -1)
			{
				if(%showoutput)
				{
					WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: NT Name missing (" @ %targetname SPC "at event" SPC %eventid @ ")");
				}
				%ret = 0;
				continue;
			}
			%classname = "fxDTSbrick";
		}
		if(%classname $= "")
		{
			for(%x=0;%x<getFieldCount($InputEvent_TargetList[fxDTSbrick,%inputIdx]);%x++)
			{
				// Grats on reading the script
				// Additional credit to Truce for bitching out
				//  when he was meant to make the mover,
				//  and making me have to do it myself.
				// No full credit for him.
				if(getWord(getField($InputEvent_TargetList[fxDTSbrick,%inputIdx],%x),0) $= %target)
				{
					%classname = getWord(getField($InputEvent_TargetList[fxDTSbrick,%inputIdx],%x),1);
					break;
				}
			}
			if(%classname $= "")
			{
				if(%showoutput)
				{
					WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Target type not found (" @ %target SPC "at event" SPC %eventid @ ")");
				}
				%ret = 0;
				continue;
			}
		}
		if(findOutputEvent(%classname,%output) == -1)
		{
			if(%showoutput)
			{
				WrenchEventsDlg.ShowStatus("<color:FF5555>Error in loading: Output event nonexistant (" @ %output SPC "at event" SPC %eventid @ ")");
			}
			%ret = 0;
			continue;
		}
	}
	%FO.close();
	%FO.delete();
	return %ret;
}
function WrenchEventsDlg::FinishLoading(%gui,%filename,%numevents,%numerrors)
{
	EGplus_Refresh();
	if($EventsGUIplus::CloseAfterOp)
	{
		EGplus_Main.close($EventsGUIplus::ShowHideInstant);
	}
	WrenchEventsDlg.ShowStatus("<color:55FF55>Loaded" SPC %numevents SPC "events from" SPC %filename @ ".txt" @ ((%numerrors != 0) ? " (" @ %numerrors SPC "errors)" : ""));
}